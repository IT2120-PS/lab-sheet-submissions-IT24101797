setwd("C://Users/user/OneDrive/Desktop/IT24101797")
p <- (25 - 10) / 40
p
##Q2
lambda <- 1/3
p2 <- pexp(2, rate = lambda)
p2
##Q3
p3<- 1-pnorm(130,mean = 100,sd= 15)
p3
p3_2<-qnorm(0.95,mean = 100,sd=15)
p3_2
